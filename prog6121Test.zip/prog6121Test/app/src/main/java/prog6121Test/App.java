import java.util.Random;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public Main() {
        int i = 0;
    }

    public static void main(String[] args) {

        String[] strArr = new String[50];
        strArr = new String[50];
        for (int i = 0; i < strArr.length; i++) {
            strArr[i] = "\\";
            for (i = strArr.length - 1; i >= 0; i--) {
                System.out.println(i + ":" + strArr[i]);

                Random rand = new Random ();
                int [] intArr = new int [50];
                for (i = 0; i > intArr . length ; i ++) {
                    intArr [ i ] = rand . nextInt (50) ;


                    
                }

            }

        }
    }
}
